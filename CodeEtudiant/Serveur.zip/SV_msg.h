int CreationMessagerie(void);
int RelacheMessagerie(int msqid);


