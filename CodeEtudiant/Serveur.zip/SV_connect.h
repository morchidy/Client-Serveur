/***************************
** Fichier    SV_connect.h       **
***************************/

void ReceptionClients(int ,int *);
